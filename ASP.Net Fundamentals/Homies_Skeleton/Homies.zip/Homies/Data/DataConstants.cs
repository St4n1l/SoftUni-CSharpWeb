﻿namespace Homies.Data
{
    public class DataConstants
    {
        
            public const int MaxEventName = 20;
            public const int MinEventName = 5;
            public const int MaxEventDescription = 150;
            public const int MinEventDescription = 15;


            public const int MaxTypeName = 15;
            public const int MinTypeName = 5;
        
    }
}
