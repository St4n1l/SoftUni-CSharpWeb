﻿using Microsoft.EntityFrameworkCore;
using WebFitnessApp.Contracts;
using WebFitnessApp.Data;

namespace WebFitnessApp.Services.Instructor
{
    public class InstructorService : IInstructorService
    {
        private readonly ApplicationDbContext _data;

        public InstructorService(ApplicationDbContext data)
        {
            _data = data;
        }

        public Task Create(string userId, string phoneNumber)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> ExistsById(string userId)
        {
            return await _data.FitnessInstructors.AnyAsync(i => i.UserId.ToString() == userId);
        }

        public async Task<bool> UserHasWorkouts(string userId)
        {
            return await _data.Workouts.AnyAsync(w => w.)
        }

        public async Task<bool> UserWithPhoneNumberExists(string phoneNumber)
        {
            return await _data.FitnessInstructors.AnyAsync(i => i.PhoneNumber == phoneNumber);
        }
    }
}
