﻿namespace WebFitnessApp.Data.ViewModels
{
    public class WorkoutIndexServiceModel
    {
        public int Id { get; set; }

        public string Name { get; set; } = null!;

        public string ImageUrl { get; set; } = null!;
    }
}
