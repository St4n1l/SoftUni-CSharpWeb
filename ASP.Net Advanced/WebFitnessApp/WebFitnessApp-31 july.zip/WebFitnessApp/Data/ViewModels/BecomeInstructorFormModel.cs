﻿namespace WebFitnessApp.Data.ViewModels
{
    public class BecomeInstructorFormModel
    {
    }
}
