﻿namespace WebFitnessApp.Data.ViewModels
{
    public class IndexViewModel
    {
    }
}
