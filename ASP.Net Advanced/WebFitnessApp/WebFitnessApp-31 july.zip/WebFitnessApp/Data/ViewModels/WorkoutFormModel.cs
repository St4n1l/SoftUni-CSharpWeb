﻿namespace WebFitnessApp.Data.ViewModels
{
    public class WorkoutFormModel
    {
    }
}
