﻿namespace WebFitnessApp.Data.ViewModels
{
    public class AllWorkoutsQueryModel
    {
    }
}
