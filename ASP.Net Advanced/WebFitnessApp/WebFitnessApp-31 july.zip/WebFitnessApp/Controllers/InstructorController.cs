﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using WebFitnessApp.Contracts;
using WebFitnessApp.Data.ViewModels;
using WebFitnessApp.Infrastructure;

namespace WebFitnessApp.Controllers
{
    [Authorize]
    public class InstructorController : Controller
    {
        private readonly IInstructorService _instructors;
        public InstructorController(IInstructorService instructors)
        {
            _instructors = instructors;
        }

        public async Task<IActionResult> Become()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Become(BecomeInstructorFormModel instructor)
        {
            if (await _instructors.ExistsById(User.Id()))
            {               
                return BadRequest();
            }

            return RedirectToAction(nameof(WorkoutController.All), "Workouts");
        }        
    }
}
