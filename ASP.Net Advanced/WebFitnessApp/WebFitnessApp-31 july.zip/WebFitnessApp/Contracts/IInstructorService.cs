﻿using System.Runtime.InteropServices;

namespace WebFitnessApp.Contracts
{
    public interface IInstructorService
    {
        Task<bool> ExistsById(string userId);

        Task<bool> UserWithPhoneNumberExists(string phoneNumber);

        Task<bool> UserHasWorkouts (string userId);

        Task Create(string userId, string phoneNumber);
    }
}
